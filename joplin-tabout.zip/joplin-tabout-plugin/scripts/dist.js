'use strict';

const fs   = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const distDir      = path.join(__dirname, '..', 'dist');
const manifestPath = path.join(__dirname, '..', 'manifest.json');
const manifest     = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const outFile      = path.join(
  __dirname, '..',
  `${manifest.id}-v${manifest.version}.jpl`
);

const files = fs.readdirSync(distDir).join(' ');
const cmd = `cd "${distDir}" && tar -cf "${outFile}" ${files}`;
execSync(cmd, { stdio: 'inherit', shell: true });

console.log(`\nPackage created: ${outFile}`);
console.log('Verify contents:');
execSync(`tar -tf "${outFile}"`, { stdio: 'inherit', shell: true });
console.log('\nInstall via Tools → Options → Plugins → Install from file.');
